<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Milad Personal Website</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="/assets/css/bootstrap.min.css" >
    <!-- Fonts -->
    <link rel="stylesheet" type="text/css" href="/assets/fonts/font-awesome.min.css">
    <!-- Icon -->
    <link rel="stylesheet" type="text/css" href="/assets/fonts/simple-line-icons.css">
    <!-- Slicknav -->
    <link rel="stylesheet" type="text/css" href="/assets/css/slicknav.css">
    <!-- Menu CSS -->
    <!-- <link rel="stylesheet" type="text/css" href="/assets/css/menu_sideslide.css"> -->
    <!-- Slider CSS -->
    <!-- <link rel="stylesheet" type="text/css" href="/assets/css/slide-style.css"> -->
    <!-- Nivo Lightbox -->
    <link rel="stylesheet" type="text/css" href="/assets/css/nivo-lightbox.css" >
    <!-- Animate -->
    <link rel="stylesheet" type="text/css" href="/assets/css/animate.css">
    <!-- Main Style -->
    <link rel="stylesheet" type="text/css" href="/assets/css/main.css">
    <!-- Responsive Style -->
    <link rel="stylesheet" type="text/css" href="/assets/css/responsive.css">

  </head>
  <body>

    <!-- Header Area wrapper Starts -->
    <header id="header-wrap">
      <!-- Navbar Start -->
      <nav class="navbar navbar-expand-lg fixed-top scrolling-navbar indigo">
        <div class="container">
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-navbar" aria-controls="main-navbar" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
              <span class="icon-menu"></span>
              <span class="icon-menu"></span>
              <span class="icon-menu"></span>
            </button>
            <a href="index.html" class="navbar-brand"><img src="/assets/img/logo.png" alt=""></a>
          </div>
          <div class="collapse navbar-collapse" id="main-navbar">
            <ul class="onepage-nev navbar-nav mr-auto w-100 justify-content-end clearfix">
              <li class="nav-item active">
                <a class="nav-link" href="#hero-area">
                  Home
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#about">
                  About
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#skills">
                  skills
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#resume">
                  Resume
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#portfolios">
                  Work
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#contact">
                  Contact
                </a>
              </li>
            </ul>
          </div>
        </div>

        <!-- Mobile Menu Start -->
        <ul class="onepage-nev mobile-menu">
          <li>
            <a href="#home">Home</a>
          </li>
          <li>
            <a href="#about">about</a>
          </li>
          <li>
            <a href="#skills">skills</a>
          </li>
          <li>
            <a href="#resume">resume</a>
          </li>
          <li>
            <a href="#portfolio">Work</a>
          </li>
          <li>
            <a href="#contact">Contact</a>
          </li>
        </ul>
        <!-- Mobile Menu End -->
      </nav>
      <!-- Navbar End -->

      <!-- Hero Area Start -->
      <div id="hero-area" class="hero-area-bg">
        <div class="overlay"></div>
        <div class="container">
          <div class="row">
            <div class="col-md-12 col-sm-12 text-center">
              <div class="contents">
<!--                <h2 class="head-title wow fadeInUp" data-wow-delay="0.2s">Milad</h2>-->
                <h5 class="head-title wow fadeInUp" data-wow-delay="0.4s">Milad</h5>
                <h6 class="head-title wow fadeInUp" data-wow-delay="0.4s">Aghamohamadnia</h6>
                <p class="script-font wow fadeInUp" data-wow-delay="0.6s">Applied Data Scientist and Machine Learning Engineer</p>
                <ul class="social-icon wow fadeInUp" data-wow-delay="0.8s">

                  <li>
                    <a class="github" href="https://github.com/miladaghamohamadnia"><i class="icon-social-github"></i></a>
                  </li>
                  <li>
                    <a class="linkedin" href="https://www.linkedin.com/in/milad-aghamohamadnia-19a3a1181"><i class="icon-social-linkedin"></i></a>
                  </li>
                  <li>
                    <a class="google" href="https://scholar.google.com/citations?hl=en&user=OPOy4IkAAAAJ&view_op=list_works&sortby=pubdate"><i class="icon-social-google"></i></a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Hero Area End -->

    </header>
    <!-- Header Area wrapper End -->

    <!-- About Section Start -->
    <section id="about" class="section-padding">
      <div class="container">
        <div class="row">

          <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
            <div class="profile-wrapper wow fadeInRight" data-wow-delay="0.3s">
              <div class="img-thumb-face wow fadeInLeft" data-wow-delay="0.3s">
                  <img class="img-fluid" src="/assets/img/about/Milad+Aghamohamadnia.jpeg" alt="">
              </div>
              <h3>About Me</h3>
              <p>Milad’s work draws on his background in statistics, data analysis, and machine learning. Currently, Milad is pursuing PhD in Civil Engineering from NYU and prior to that, has earned M.Sc and B.Sc in Remote Sensing and Geomatics Engineering from University of Tehran and has recently worked as Data Scientist at Descartes Labs.</p>
              <a href="https://drive.google.com/file/d/1sBtho2a34yhLhu4oG_RcI5bQ8n2kD9Oe/view?usp=sharing" class="btn btn-common"><i class="icon-paper-clip"></i> Download Resume</a>
            </div>
          </div>   
          <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
            <div class="img-thumb wow fadeInLeft" data-wow-delay="0.3s">
              <img class="img-fluid" src="/assets/img/about/about-1.jpg" alt="">
            </div>
          </div> 
        </div>
      </div>
    </section>
    <!-- About Section End -->

    <!-- skills Section Start -->
    <section id="skills" class="skills section-padding">
      <h2 class="section-title wow flipInX" data-wow-delay="0.4s">What I do</h2>
      <div class="container">
        <div class="row">
          <!-- skills item -->
          <div class="col-md-6 col-lg-3 col-xs-12">
            <div class="skills-item wow fadeInDown" data-wow-delay="0.3s">
              <div class="icon">
                <i class="icon-globe"></i>
              </div>
              <div class="skills-content">
                <h3><a href="#">Remote Sensing</a></h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse condi.</p>
              </div>
            </div>
          </div>
          <!-- skills item -->
          <div class="col-md-6 col-lg-3 col-xs-12">
            <div class="skills-item wow fadeInDown" data-wow-delay="0.6s">
              <div class="icon">
                <i class="icon-eye"></i>
              </div>
              <div class="skills-content">
                <h3><a href="#">Computer Vision</a></h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse condi.</p>
              </div>
            </div>
          </div>
          <!-- skills item -->
          <div class="col-md-6 col-lg-3 col-xs-12">
            <div class="skills-item wow fadeInDown" data-wow-delay="0.9s">
              <div class="icon">
                <i class="icon-layers"></i>
              </div>
              <div class="skills-content">
                <h3><a href="#">Deep Learning</a></h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse condi.</p>
              </div>
            </div>
          </div>
          <!-- skills item -->
          <div class="col-md-6 col-lg-3 col-xs-12">
            <div class="skills-item wow fadeInDown" data-wow-delay="1.2s">
              <div class="icon">
                <i class="icon-chart"></i>
              </div>
              <div class="skills-content">
                <h3><a href="#">Statistical Modeling</a></h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse condi.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- skills Section End -->

    <!-- Resume Section Start -->
    <div id="resume" class="section-padding">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 col-md-6 col-sm-6">
            <div class="education wow fadeInRight" data-wow-delay="0.3s">
              <ul class="timeline">
                <li>
                  <i class="icon-graduation"></i>
                  <h2 class="timelin-title">Education</h2>
                </li>
                <li>
                  <div class="content-text">
                    <h3 class="line-title">Ph.D In Civil Engineering</h3>
                    <h3 class="line-title-location">
                    @ New York University - NYU</h3>
                    <span>2014 - 2019</span>
                    <p class="line-text">Expenses as material breeding insisted building to in. Continual so distrusts pronounce by unwilling listening. Thing do taste on we manor.</p>
                  </div>
                </li>
                <li>
                  <div class="content-text">
                    <h3 class="line-title">M.Sc In Remote Sensing</h3>
                    <h3 class="line-title-location">
                    @ University of Tehran</h3>
                    <span>2012 - 2014</span>
                    <p class="line-text">Expenses as material breeding insisted building to in. Continual so distrusts pronounce by unwilling listening. Thing do taste on we manor.</p>
                  </div>
                </li>
                <li>
                  <div class="content-text">
                    <h3 class="line-title">B.Sc In Geomatics Engineering</h3>
                    <h3 class="line-title-location">
                    @ University of Tehran</h3>           <span>2008 - 2012</span>
                    <p class="line-text">Expenses as material breeding insisted building to in. Continual so distrusts pronounce by unwilling listening. Thing do taste on we manor.</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-6 col-md-6 col-sm-6">
            <div class="experience wow fadeInRight" data-wow-delay="0.6s">
              <ul class="timeline">
                <li>
                  <i class="icon-briefcase"></i>
                  <h2 class="timelin-title">Experience</h2>
                </li>
                <li>
                  <div class="content-text">
                    <h3 class="line-title">Data Scientist</h3>
                    <h3 class="line-title-location">
                    @ Descartes Labs</h3>
                    <span>June 2017 - June 2018</span>
                    <p class="line-text">
                        ❏ Implementing developed solutions for large-scale, real-world problems}
                        <br>
                        ❏ Working collaboratively at a high paced startup
                        <br>
                        ❏ Developed a processing pipeline for object detection based on cutting edge AI using arrays of
                        data including vector layers and raster images
                        ❏ Preprocessing and parallelizing tasks on image tiles for higher performance
                    </p>
                  </div>
                </li>
                <li>
                  <div class="content-text">
                    <h3 class="line-title">Assoc. Research Scientist</h3>
                    <h3 class="line-title-location">
                    @ Center for Urban Science and Progress - CUSP</h3>
                    <span>Jun 2015 - Jun 2017</span>
                    <p class="line-text">
                        ❏ Responsible for developing algorithms and coding with Python
                        <br>
                        ❏ Developed a process pipeline for long wave infrared Hyperspectral data cubes analysis
                        <br>
                        ❏ Analyzed 311 dataset to determine new content and services. Set out auxiliary information layer
                        for guided spatial searching processes
                        <br>
                        ❏ Served as capstone project mentor of master program students
                      </p>
                  </div>
                </li>
                <li>
                  <div class="content-text">
                    <h3 class="line-title">Graduate Research Assistant</h3>
                    <h3 class="line-title-location">
                    @ NYU - Tandon School of Engineering</h3>
                    <span>Sep 2015 - Jun 2019</span>
                    <p class="line-text">
                        ❏ Sensor data analysis using deep learning and machine learning from urban sensors
                        <br>
                        ❏ Object detection and predictive modelling through computer vision of video feed
                        <br>
                        ❏ 3D modelling of NYC surface temperature by fusion of ground and space based image
                        <br>
                        ❏ Parallel processing in distributed platforms via SLURM
                      </p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Resume Section End -->

    <!-- Portfolio Section -->
    <section id="portfolios" class="section-padding">
      <!-- Container Starts -->
      <div class="container">        
        <h2 class="section-title wow flipInX" data-wow-delay="0.4s"> Works and Projects</h2>
        <div class="row">          
          <div class="col-md-12">
            <!-- Portfolio Controller/Buttons -->
            <div class="controls text-center">
              <a class="filter active btn btn-common" data-filter="all">
                All 
              </a>
              <a class="filter btn btn-common" data-filter=".machineLearning">
                Machine Learning 
              </a>
              <a class="filter btn btn-common" data-filter=".remoteSensing">
                Remote Sensing
              </a>
              <a class="filter btn btn-common" data-filter=".computerVision">
                Computer Vision 
              </a>
            </div>
            <!-- Portfolio Controller/Buttons Ends-->
          </div>

          <!-- Portfolio Recent Projects -->
          <div id="portfolio" class="row wow fadeInDown" data-wow-delay="0.4s">
            <!-- <div class="col-sm-6 col-md-4 col-lg-4 col-xl-4 mix computerVision">
              <div class="portfolio-item">
                <div class="shot-item">
                  <img src="/assets/img/gallery/img-1.jpg" alt="" />  
                  <div class="overlay">
                    <div class="icons">
                      <a class="lightbox preview" href="/assets/img/gallery/img-1.jpg">
                        <i class="icon-eye"></i>
                      </a>
                      <a class="link" href="#">
                        <i class="icon-social-github"></i>
                      </a>
                    </div>
                  </div>
                </div>               
              </div>
            </div> -->
            <!-- <div class="col-sm-6 col-md-4 col-lg-4 col-xl-4 mix remoteSensing">
              <div class="portfolio-item">
                <div class="shot-item">
                  <img src="/assets/img/gallery/img-2.jpg" alt=""/> 
                  <div class="overlay">
                    <div class="icons">
                      <a class="lightbox preview" href="/assets/img/gallery/img-2.jpg">
                        <i class="icon-eye"></i>
                      </a>
                      <a class="link" href="#">
                        <i class="icon-social-github"></i>
                      </a>
                    </div>
                  </div>
                </div>               
              </div>
            </div> -->
            <div class="col-sm-6 col-md-4 col-lg-4 col-xl-4 mix machineLearning">
              <div class="portfolio-item">
                <div class="shot-item">
                  <img src="/assets/img/gallery/img-3.png" alt=""/> 
                  <div class="overlay">
                    <div class="icons">
                      <a class="lightbox preview" href="/assets/img/gallery/img-3-1.png">
                        <i class="icon-eye"></i>
                      </a>
                      <a class="link" href="/nycheat">
                        <i class="icon-link"></i>
                      </a>
                      <a class="glink" href="https://github.com/miladaghamohamadnia">
                        <i class="icon-social-github"></i>
                      </a>
                    </div>
                  </div>
                </div>               
              </div>
            </div>
            
    <!-- Portfolio Section - second row -->
<!--           
            <div class="col-sm-6 col-md-4 col-lg-4 col-xl-4 mix development design">
              <div class="portfolio-item">
                <div class="shot-item">
                  <img src="/assets/img/gallery/img-4.jpg" alt="" /> 
                  <div class="overlay">
                    <div class="icons">
                      <a class="lightbox preview" href="/assets/img/gallery/img-4.jpg">
                        <i class="icon-eye"></i>
                      </a>
                      <a class="link" href="#">
                        <i class="icon-link"></i>
                      </a>
                    </div>
                  </div>
                </div>               
              </div>
            </div>
            <div class="col-sm-6 col-md-4 col-lg-4 col-xl-4 mix development">
              <div class="portfolio-item">
                <div class="shot-item">
                  <img src="/assets/img/gallery/img-5.jpg" alt="" /> 
                  <div class="overlay">
                    <div class="icons">
                      <a class="lightbox preview" href="/assets/img/gallery/img-5.jpg">
                        <i class="icon-eye"></i>
                      </a>
                      <a class="link" href="#">
                        <i class="icon-link"></i>
                      </a>
                    </div>
                  </div>
                </div>               
              </div>
            </div>
            <div class="col-sm-6 col-md-4 col-lg-4 col-xl-4 mix print design">
              <div class="portfolio-item">
                <div class="shot-item">
                  <img src="/assets/img/gallery/img-6.jpg" alt=""/>
                  <div class="overlay">
                    <div class="icons">
                      <a class="lightbox preview" href="/assets/img/gallery/img-6.jpg">
                        <i class="icon-eye"></i>
                      </a>
                      <a class="link" href="#">
                        <i class="icon-link"></i>
                      </a>
                    </div>
                  </div>
                </div>               
              </div>
            </div>
          </div>
        </div>
      </div>
-->
      <!-- Container Ends -->
    </section>
    <!-- Portfolio Section Ends --> 

    <!-- Counter Area Start-->
<!--
    <section class="counter-section section-padding">
      <div class="container">
        <div class="row">
          <div class="col-md-3 col-sm-6 work-counter-widget text-center">
            <div class="counter wow fadeInDown" data-wow-delay="0.3s">
              <div class="icon"><i class="icon-briefcase"></i></div>
              <div class="counterUp">250</div>
              <p>Project Working</p>
            </div>
          </div>
          <div class="col-md-3 col-sm-6 work-counter-widget text-center">
            <div class="counter wow fadeInDown" data-wow-delay="0.6s">
              <div class="icon"><i class="icon-check"></i></div>
              <div class="counterUp">950</div>
              <p>Project Done</p>
            </div>
          </div>
          <div class="col-md-3 col-sm-6 work-counter-widget text-center">
            <div class="counter wow fadeInDown" data-wow-delay="0.9s">
              <div class="icon"><i class="icon-diamond"></i></div>
              <div class="counterUp">150</div>
              <p>Awards Received</p>
            </div>
          </div>
          <div class="col-md-3 col-sm-6 work-counter-widget text-center">
            <div class="counter wow fadeInDown" data-wow-delay="1.2s">
              <div class="icon"><i class="icon-heart"></i></div>
              <div class="counterUp">299</div>
              <p>Happy Clients</p>
            </div>
          </div>
        </div>
      </div>
    </section> 
-->
    <!-- Counter Area End-->

    <!-- Contact Section Start -->
    <section id="contact" class="section-padding">      
      <div class="contact-form">
        <div class="container">
          <div class="row contact-form-area wow fadeInUp" data-wow-delay="0.4s">          
<!--
            <div class="col-md-6 col-lg-6 col-sm-12">
              <div class="contact-block">
                <h2>Contact Form</h2>
                <form id="contactForm">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <input type="text" class="form-control" id="name" name="name" placeholder="Name" required data-error="Please enter your name">
                        <div class="help-block with-errors"></div>
                      </div>                                 
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <input type="text" placeholder="Email" id="email" class="form-control" name="email" required data-error="Please enter your email">
                        <div class="help-block with-errors"></div>
                      </div> 
                    </div>
                     <div class="col-md-12">
                      <div class="form-group">
                        <input type="text" placeholder="Subject" id="msg_subject" class="form-control" required data-error="Please enter your subject">
                        <div class="help-block with-errors"></div>
                      </div>
                    </div>
                    <div class="col-md-12">
                      <div class="form-group"> 
                        <textarea class="form-control" id="message" placeholder="Your Message" rows="5" data-error="Write your message" required></textarea>
                        <div class="help-block with-errors"></div>
                      </div>
                      <div class="submit-button">
                        <button class="btn btn-common" id="submit" type="submit">Send Message</button>
                        <div id="msgSubmit" class="h3 text-center hidden"></div> 
                        <div class="clearfix"></div> 
                      </div>
                    </div>
                  </div>            
                </form>
              </div>
            </div>
-->
            <div class="col-md-6 col-lg-6 col-sm-12">
              <div class="footer-right-area wow fadeIn">
                <h2>Contact Address</h2>
                <div class="footer-right-contact">
                  <div class="single-contact">
                    <div class="contact-icon">
                      <i class="fa fa-map-marker"></i>
                    </div>
                    <p>New York City, NY</p>
                  </div>
                  <div class="single-contact">
                    <div class="contact-icon">
                      <i class="fa fa-envelope"></i>
                    </div>
                    <p><a href="mailto:milad@nyu.edu">milad@nyu.edu</a></p>
                  </div>
                  <div class="single-contact">
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-12">
            <object style="border:0; height: 450px; width: 100%;" data="https://maps.google.com/maps?q=nye%20tandon&t=&z=13&ie=UTF8&iwloc=&output=embed"></object>
            </div>
          </div>
        </div>
      </div>   
    </section>
    <!-- Contact Section End -->

    <!-- Footer Section Start -->
    <footer class="footer-area section-padding">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="footer-text text-center wow fadeInDown" data-wow-delay="0.3s">
              <ul class="social-icon">
                <li>
                  <a class="github" href="https://github.com/miladaghamohamadnia"><i class="icon-social-github"></i></a>
                </li>
                <li>
                  <a class="linkedin" href="https://www.linkedin.com/in/milad-aghamohamadnia-19a3a1181"><i class="icon-social-linkedin"></i></a>
                </li>
                <li>
                  <a class="google" href="https://scholar.google.com/citations?hl=en&user=OPOy4IkAAAAJ&view_op=list_works&sortby=pubdate"><i class="icon-social-google"></i></a>
                </li>
              </ul>
              <p>Copyright © 2018 UIdeck All Right Reserved</p>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- Footer Section End -->
                      
    <!-- Go to Top Link -->
    <a href="#" class="back-to-top">
      <i class="icon-arrow-up"></i>
    </a>

    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="/assets/js/jquery-min.js"></script>
    <script src="/assets/js/popper.min.js"></script>
    <script src="/assets/js/bootstrap.min.js"></script>
    <script src="/assets/js/jquery.mixitup.js"></script>
    <script src="/assets/js/jquery.counterup.min.js"></script>
    <script src="/assets/js/waypoints.min.js"></script>
    <script src="/assets/js/wow.js"></script>
    <script src="/assets/js/jquery.nav.js"></script>
    <script src="/assets/js/jquery.easing.min.js"></script>  
    <script src="/assets/js/nivo-lightbox.js"></script>
    <script src="/assets/js/jquery.slicknav.js"></script>
    <script src="/assets/js/main.js"></script>
    <!-- <script src="/assets/js/form-validator.min.js"></script> -->
    <!-- <script src="/assets/js/contact-form-script.min.js"></script> -->
    <!-- <script src="/assets/js/map.js"></script> -->
      
  </body>
</html>
